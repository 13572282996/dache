
var decrypt = new JSEncrypt();
var encrypt = new JSEncrypt();
decrypt.setPrivateKey("MIICXgIBAAKBgQCy0jx1enDZCUyKb5p9QYtFrwSA7YFDplvKmroxqfK/ndSM0MISZ0yNF/QAId86ot/cpKsWYXFyWLBLWU1mPpNMEyS76TVI/RTrfSiq3xI/VUyQ6f564Pd+uV55USWUbC187Qhd/GNLMkMlikdvl4/yTFf+jjXW50za4GGy8LnhfwIDAQABAoGBAKgTgS4ukqj824t3EK9QjvZFZadFFW2fjMFnI0EQ6xB96c0dXnxryYEIlZgWPjpf4qgBwql7l2URxUpdOqmygUC5PoGwI8Z89EkVcPIpgdZhd+skaY5IATE9Lt3yY1dZB6aBBxarlCD89Du/SF7FSa+QXvIEV+YY5ZvXpSumBOvhAkEA6S4BB/YCHjoO3hpRT8DyMVo65pBsr6exdmb3XEaH8KchoIMTbp0d6/n24qJSaaa5+C8Rx+tJ3OIBSdNi9yfgcQJBAMRSWwzYTI6TfO69yxXB1efyTNo2e950DpUoaOMTELQQ5mk8TV1VapLrgl2AxkOXK6UJM4LahKi4r+Yrr+8g2O8CQHaGC8AgK7Nxj10Vw37mdDThyE6p2pTuiCXG8LTWpQKN8WnFNntjIXJw/Cz2lS1eseiVBFS6JDFCL6V27Tbz7gECQQCvwQbQLggDkBhFZ1YbaUeFec7BgAtOsFmpwN59g0Dt4z9TMPAVwXVCiGJSMQnN0tT4z47084nVvlmC1tOPYbmzAkEArQ3JUXNhhLNIlb6/EucJKTvxRGud0uL/R3rgDnugioCim2CSN2W+hPO1qHV4Ii0gAzxmm/EyxagPMj9THi1OEw==");
encrypt.setPublicKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCy0jx1enDZCUyKb5p9QYtFrwSA7YFDplvKmroxqfK/ndSM0MISZ0yNF/QAId86ot/cpKsWYXFyWLBLWU1mPpNMEyS76TVI/RTrfSiq3xI/VUyQ6f564Pd+uV55USWUbC187Qhd/GNLMkMlikdvl4/yTFf+jjXW50za4GGy8LnhfwIDAQAB");
		
/**
 * RSA公钥加密
 * @param {Object} content
 */
var RSAencrypt = function(content) {
	return encrypt.encryptLong(JSON.stringify(content));
}

/**
 * RSA私钥解密
 * @param {Object} content
 */
var  RSAdecrypt = function(content){
	return decrypt.decryptLong(content);
}
