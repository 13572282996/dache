//定时操作工具类
//times为-1时无限次
var timing = function (longtime , times , func,over) {
	var intervalId = 0;
	var i = 0;
	var flag = true;
	return{
		 init:function(){
			i = 0;
			intervalId = setInterval(function () {
			if(i < times || times == -1 ) {
				if(flag){ 
					func();
					i++;
				}
			}else {
				clearInterval(intervalId);
				intervalId = 0;
				if(over != null && over !=""){
					over();
				}
			}
			
		} , longtime);
		},
		stop:function() {
			if(intervalId != 0) {
				clearInterval(intervalId);
				intervalId = 0;
				if(over != null && over !=""){
					over();
				}
			}
			
		},
		
		//暂停
		pause:function() {
			flag = false;		
		},
		//继续
		continues:function(){
			flag = true;
		},
		//获取剩余次数
		getTimes:function() {
			return times - i;
		}
	}
};
