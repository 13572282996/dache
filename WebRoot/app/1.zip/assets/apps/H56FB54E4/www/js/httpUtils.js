var bastUrl = "https://ip.ixszc.com/";

function post( url , put ,success ,errors) {
	put.token=localStorage.getItem('token');	
	console.log(JSON.stringify(put));
	mui.ajax( bastUrl+url,{
	data:put,
	dataType:'json',//服务器返回json格式数据
	type:'post',//HTTP请求类型
	timeout:10000,//超时时间设置为10秒；
	success:function(data){
		success(data);
		//服务器返回响应，根据响应结果，分析是否登录成功；
		if(data.code ==2000) {
			mui.toast("请先登录");
			mui.openWindow({
				id:"login",
				url:"login.html"
				
			});
			return;
		}
		
	},
	error:function(xhr,type,errorThrown){
		//异常处理；
		console.log(errorThrown);
		mui.toast("链接服务器失败");
		errors();
	}
});
	
}
